# HTML_All-in-one_School-Website
Multipage website with active links and responsive layout made with HTML 5 only.
